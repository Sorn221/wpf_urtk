﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lr4
{
    internal class telephone
    {
        public string Title { get; set; }
        public string Company { get; set; }
        public decimal Price { get; set; }
    }
}
